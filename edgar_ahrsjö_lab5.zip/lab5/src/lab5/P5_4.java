package lab5;

public class P5_4 {

    public static void main(String[] args) {
        CheckString2 text = new CheckString2("");

        System.out.println(text.getString());
        System.out.println(text.middle());
        System.out.println(text.countVowels());
        //find strings
       text.findString("test");
        //count words
        text.countWords();
    }
}