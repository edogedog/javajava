package lab5;

import java.util.Collections;

public class ManipulateString {

    private String stri;

    public ManipulateString(String text) {
        stri = text;
    }

    public String getString() {
        return stri;
    }

    public String middle() {
        if (stri.isEmpty()) {
            return "";
        }

        int mitten = stri.length() / 2;

        if (stri.length() % 2 == 0) {
            return stri.substring(mitten - 1, mitten + 1);
        } else {
            return stri.substring(mitten, mitten + 1);
        }
    }

    public int countVowels() {
        int antal = 0;
        String vokaler = "aouåeiyäöAOUÅEIYÄÖ";

        for (int i = 0; i < stri.length(); i++) {
            if (vokaler.indexOf(stri.charAt(i)) >= 0) {
                antal++;
            }
        }

        return antal;
    }

public int findString(String ord) {
	int startindex = stri.indexOf(ord);
	System.out.println(startindex);
	return startindex;
	
}

public int countWords() {
	if (stri == "") {
		System.out.println("0");
		return 0;
	}
	int totalarray = stri.trim().split("\\s+").length;
	System.out.println(totalarray);
	return totalarray;
}
public String scramble() {
    char[] array = stri.toCharArray();

    for (int i = 0; i < array.length; i++) {
        int random = (int) (Math.random() * array.length);

        char temp = array[i];
        array[i] = array[random];
        array[random] = temp;
    }

    return new String(array);
}

public String reverse() {
    char[] array = stri.toCharArray();
    char[] backwards = new char[array.length];

    for (int i = 0; i < array.length; i++) {
        backwards[i] = array[array.length - 1 - i];
    }

    return new String(backwards);
}

public String insertAt(int where, String text) {
    return stri.substring(0, where) + text + stri.substring(where);
}

public String removeCharAt(int where) {
    return stri.substring(0, where) + stri.substring(where + 1);
}
}

