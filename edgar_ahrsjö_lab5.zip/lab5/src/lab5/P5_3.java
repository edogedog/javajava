package lab5;

public class P5_3 {
	public static void main(String[] args) {
		CheckNumberArray cnas = new CheckNumberArray();
		
		//testmeddelande för debug
		System.out.println("test add number");
		//metoden addnbr kallas med 4
		cnas.addNbr(1);
		cnas.addNbr(2);
		cnas.addNbr(3);
		cnas.addNbr(4);
		cnas.addNbr(5);
		
		//getsum
		cnas.getSum();
		
		//getAverage
		cnas.getAverage();
		
		//isallsame
		cnas.isAllTheSame();
		
		//isaccorder
		cnas.isAccOrder();
		
		//isdescorder
		cnas.isDesOrder();
		
		//isordered
		cnas.isOrdered();
		
		
		
		
		
		
		
		
	}

}
