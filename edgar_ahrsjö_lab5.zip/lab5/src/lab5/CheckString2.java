package lab5;


public class CheckString2 {

    private String stri;

    public CheckString2(String text) {
        stri = text;
    }

    public String getString() {
        return stri;
    }

    public String middle() {
        if (stri.isEmpty()) {
            return "";
        }

        int mitten = stri.length() / 2;

        if (stri.length() % 2 == 0) {
            return stri.substring(mitten - 1, mitten + 1);
        } else {
            return stri.substring(mitten, mitten + 1);
        }
    }

    public int countVowels() {
        int antal = 0;
        String vokaler = "aouåeiyäöAOUÅEIYÄÖ";

        for (int i = 0; i < stri.length(); i++) {
            if (vokaler.indexOf(stri.charAt(i)) >= 0) {
                antal++;
            }
        }

        return antal;
    }

public int findString(String ord) {
	int startindex = stri.indexOf(ord);
	System.out.println(startindex);
	return startindex;
	
}

public int countWords() {
	if (stri == "") {
		System.out.println("0");
		return 0;
	}
	int totalarray = stri.trim().split("\\s+").length;
	System.out.println(totalarray);
	return totalarray;
}
}