package lab5;

public class CheckNumberArray {
	private static int MAX_ELEMENTS = 10;
	private int[] arrayOfInt;
	private int nbrOfElements;
		
	
	public CheckNumberArray() {
		//skapar arrayn för 10 tal
		arrayOfInt = new int[10];
		MAX_ELEMENTS = 10;
		nbrOfElements = 0;
		
		
		for (int i = 0; i < arrayOfInt.length; i++) {
			arrayOfInt[i] = (int)(Math.random() * 100) + 1;
		}
		
	}
	
	public void addNbr(int senap) {
		//ta ett emot heltal o add number in array if ledigt
		//räknar up nbrofelements
		if (nbrOfElements < MAX_ELEMENTS) {
			arrayOfInt[nbrOfElements] = senap;
			nbrOfElements +=1;
		}
		System.out.println(arrayOfInt[nbrOfElements-1]);
		
	}
	public int getNbrOfElements() {
		//returnerar entries i arrayn
		System.out.println(nbrOfElements);
		return nbrOfElements;
		
	}
	public int getSum() {
		//summan av entries
		int getSum;
		getSum = 0;
		for (int i = 0; i < nbrOfElements; i++) {
			getSum += arrayOfInt[i];
		}
		System.out.println(getSum);
		return getSum;
		
		
	}
	public double getAverage() {
		//medelvärde
		double getSum;
		getSum = 0;
		for (int i = 0; i < nbrOfElements; i++) {
			
			getSum += arrayOfInt[i];
		}
		System.out.println(getSum/nbrOfElements);
		return getSum/nbrOfElements;
		
	}
	public boolean isAllTheSame() {
		//är alla samma
				int oldele;
				oldele = arrayOfInt[0];
				for (int i = 0; i < nbrOfElements; i++) {
										if (oldele != arrayOfInt[i]) {
						break;
					}
					if(i == nbrOfElements-1) {
						System.out.println(true);
						return true;
					}
				}
				System.out.println(false);
				return false;
		
	}
	public boolean isAccOrder() {
		//ascending order?
				int getSum;
				getSum = 0;
				for (int i = 1; i < nbrOfElements; i++) {
					if (arrayOfInt[i]<arrayOfInt[i-1]) {
						System.out.println(false);
						return false;
					}
				}
				System.out.println(true);
				return true;
	}
			
	public boolean isDesOrder() {
		//desc order?
		int getSum;
		getSum = 0;
		for (int i = 1; i < nbrOfElements; i++) {
			if (arrayOfInt[i]>arrayOfInt[i-1]) {
				System.out.println(false);
				return false;
			}
		}
		System.out.println(true);
		return true;

	}
	public boolean isOrdered() {
		//är dom ordered checka antingen asc eller dessc ifall någon är true antar att || ccheckar det..

		if (isAccOrder() || isDesOrder()) {
			System.out.println(true);
			return true;
		}
		else {
			System.out.println(false);
			return false;
		}
		}
	}