package lab5;

public class PrintArray {
	private int[] arrayOfInt;
	
	public PrintArray() {
		arrayOfInt = new int[10];
		
		for (int i = 0; i < arrayOfInt.length; i++) {
			arrayOfInt[i] = (int)(Math.random() * 100) + 1;
		}
		
	}
	
	public void printEvenIndex() {
		for (int i = 0; i < arrayOfInt.length; i++) {
			if (i%2 == 0) {
				//System.out.println("index: "+i);
				System.out.println(arrayOfInt[i]);
				
			}
		}
		
	}
	public void printEvenElement() {
		for (int i = 0; i < arrayOfInt.length; i++) {
			int y = arrayOfInt[i];
			if (y%2 == 0) {
				System.out.println(arrayOfInt[i]);
			}
		}
		
	}
	public void printReverse() {
		for (int i = arrayOfInt.length-1; i >= 0; i--) {
			System.out.println(arrayOfInt[i]);
		}
	}
	public void printFirstAndLast() {
		System.out.println(arrayOfInt[0]);
		System.out.println(arrayOfInt[9]);
		
		
	}
	public int[] getArray() {
		return arrayOfInt.clone();
	}
	
	

}
