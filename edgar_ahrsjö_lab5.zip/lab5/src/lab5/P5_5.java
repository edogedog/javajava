package lab5;

public class P5_5 {

    public static void main(String[] args) {
        ManipulateString text = new ManipulateString("detta är test");

        System.out.println(text.getString());
        System.out.println(text.middle());
        System.out.println(text.countVowels());
        //find strings
       text.findString("test");
        //count words
        text.countWords();
        System.out.println("new");
        text.scramble();
        text.reverse();
        text.insertAt(3,"lol");
        text.removeCharAt(3);
        System.out.println(text.scramble());
        System.out.println(text.reverse());
        System.out.println(text.insertAt(0, "1"));
        System.out.println(text.removeCharAt(3));
    }
}