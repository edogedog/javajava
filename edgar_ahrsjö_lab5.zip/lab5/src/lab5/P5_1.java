package lab5;

public class P5_1 {
	
	public static void main(String[] args) {
		PrintArray parray = new PrintArray();
		
		System.out.println("evenindex");
		parray.printEvenIndex();
		
		System.out.println("evenelement");
		parray.printEvenElement();
		
		System.out.println("reverse");
		parray.printReverse();
		
		System.out.println("first and last");
		parray.printFirstAndLast();
		
		System.out.println("getarray");
		parray.getArray();
		
		
		
		
		
		
		
		
	}

}

