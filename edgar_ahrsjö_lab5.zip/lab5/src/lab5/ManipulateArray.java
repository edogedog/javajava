package lab5;

public class ManipulateArray {
	private int[] arrayOfInt;
    public ManipulateArray() {
        arrayOfInt = new int[10];

        for (int i = 0; i < arrayOfInt.length; i++) {
            arrayOfInt[i] = (int) (Math.random() * 10) + 1;
        }
    	}

    public ManipulateArray(int[] arrayOfInt) {
        this.arrayOfInt = arrayOfInt;
    	}

    public int[] getArrayCopy() {
        int[] copy = new int[arrayOfInt.length];

        for (int i = 0; i < arrayOfInt.length; i++) {
            copy[i] = arrayOfInt[i];
        }
        return copy;
    	}
    public int getArraySize() {
        return arrayOfInt.length;
    }

    public String swapFirstAndLast() {
        int[] copy = getArrayCopy();

        int temp = copy[0];
        copy[0] = copy[copy.length - 1];
        copy[copy.length - 1] = temp;

        return makeString(copy);
    }

    public String rightShiftOneStep() {
        int[] copy = getArrayCopy();

        int last = copy[copy.length - 1];

        for (int i = copy.length - 1; i > 0; i--) {
            copy[i] = copy[i - 1];
        }
        copy[0] = last;
        return makeString(copy);
    }
    public int[] replaceWithBiggestNeighbor() {
        int[] result = getArrayCopy();

        for (int i = 1; i < arrayOfInt.length - 1; i++) {
            if (arrayOfInt[i - 1] > arrayOfInt[i + 1]) {
                result[i] = arrayOfInt[i - 1];
            } else {
                result[i] = arrayOfInt[i + 1];
            }
        	}

        return result;
    }
    private String makeString(int[] array) {
        String text = "[";

        for (int i = 0; i < array.length; i++) {
            text += array[i];

            if (i < array.length - 1) {
                text += ", ";
            }
        	}
        text += "]";

        return text;
    }
}