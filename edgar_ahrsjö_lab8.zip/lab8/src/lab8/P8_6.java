package lab8;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import java.io.FileNotFoundException;


public class P8_6 {
    public static void main(String[] args) throws Exception {
    	
        // Fråga efter filnamnet, öppna filen och anropa metoden.

    	// skapa kod för att läsa in ett filnamn
    	Scanner input = new Scanner(System.in); // Läser från tangentbordet
    	System.out.print("Ange filnamn: ");
    	
  	
    	
    	String in = input.nextLine();           // Sparar namnet du skriver
    	
    	File fileObject = new File(in);
    	
    	Message msg = new Message(10);

    	try {
        	Scanner fileScan = new Scanner(fileObject);
    	} catch (FileNotFoundException e) {
    		System.out.println("den filen verkar inte finnas");
    		throw e;
    	}
    	Scanner fileScan = new Scanner(fileObject); 
    	
    	int rowcount = 0;

    	while (fileScan.hasNextLine()) {
    		rowcount ++;
    		String rad = fileScan.nextLine();
    		
    		MessageRow row = new MessageRow(rad);
    		msg.addRow(row);
    		
    		
    	}
    	System.out.printf("rad: %d%n",msg.getNbrOfRows());
    	System.out.printf("ord: %d%n",msg.getNbrOfWords());
    	System.out.printf("bokstäver: %d%n",msg.getNbrOfChars());
    	System.exit(0);


  
    }
    	 
    	
    	 
    	
    }
