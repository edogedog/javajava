package lab8;
import java.nio.file.*;
import java.util.*;


public class P8_9 {

   public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);

    try {
        System.out.println("Ange infil:");
        String infil = sc.nextLine();

        System.out.println("Ange utfil:");
        String utfil = sc.nextLine();

        System.out.println("Ange offset:");
        int offset = sc.nextInt();

        String text = Files.readString(Path.of(infil));

        String resultat = caesarCrypt(text, offset);

        Files.writeString(Path.of(utfil), resultat);

        System.exit(0); // DETTA SAKNADES

    } catch (Exception e) {
        throw new InputMismatchException("Fel vid kryptering");
    }
}
    public static String caesarCrypt(String inFileText, int offsetKey) {

        String resultat = "";

        for (int i = 0; i < inFileText.length(); i++) {

          
        	char c = inFileText.charAt(i);

            if (c >= 'a' && c <= 'z') {
                c = (char) ('a' + (c - 'a' + offsetKey + 26) % 26);
            }
            else if (c >= 'A' && c <= 'Z') {
                c = (char) ('A' + (c - 'A' + offsetKey + 26) % 26);
            }
            resultat += c;
        }
        return resultat;
    }
 }