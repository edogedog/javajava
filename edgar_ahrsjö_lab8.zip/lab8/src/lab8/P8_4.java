package lab8;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import java.io.FileNotFoundException;


public class P8_4 {
    public static void main(String[] args) throws Exception {
    	
        // Fråga efter filnamnet, öppna filen och anropa metoden.

    	// skapa kod för att läsa in ett filnamn
    	Scanner input = new Scanner(System.in); // Läser från tangentbordet
    	System.out.print("Ange filnamn: ");
    	
  	
    	
    	String in = input.nextLine();           // Sparar namnet du skriver
    	
    	File fileObject = new File(in);

    	
    	try {
        	Scanner fileScan = new Scanner(fileObject); // OBS krävs exceptions..
    	} catch (FileNotFoundException e) {
    	    throw new Exception("den filen verkar inte finnas");
    	    System.exit(1);
    	}
    	Scanner fileScan = new Scanner(fileObject); // OBS krävs exceptions..


  
    	double[] columnAverage = getAvgCols(fileScan); // Anropa med färdig scanner
    	System.out.println("Medelvärdet för kolumn 1: "+columnAverage[0]);
    	System.out.println("Medelvärdet för kolumn 2: "+columnAverage[1]);
    	
    	
    	System.exit(0);
    }
    public static double[] getAvgCols(Scanner reader) {
    	// Beräkna och returnera medelvärdena här.
    	
    	double summa1 = 0;
    	double summa2 = 0;
    	int antal1 = 0;
    	int antal2 = 0;
    	double tal = 0;
    	int i = 1;
    	
    	while (i != 0) {
    		if (!reader.hasNextDouble()){
    			break;
    		}
    		tal = reader.nextDouble();
    		if (i%2==1){
    			summa1 += tal;    
    			antal1 += 1;
    			i++;
    		}
    		else
    		{
    			summa2 += tal;
    			antal2 += 1;
    			i++;
    		}
    	}
    	double x = summa1/antal1;
    	double y = summa2/antal2;
    	double[] gog = {x,y};
    	return gog;
    	
  
    }
    	
    	 
    	
    	 
    	
    }
