package lab8;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class P8_2 {
    public static void main(String[] args) throws Exception {
    	
        // öppna fil
    	String file = "mary.txt";
        Scanner read = new Scanner(file);

        // läs och printa
        System.out.println(read.nextLine());

        // stäng igen
        read.close();

        FileWriter fil = new FileWriter("mary-out.txt");

        // öppna för att skriva
        fil.write("Mary had a little lamb"
        		+ "Whose fleece was white as snow.\r\n"
        		+ "And everywhere that Mary went,\r\n"
        		+ "The lamb was sure to go!");

        // stäng filen
        fil.close();

 
    }
}