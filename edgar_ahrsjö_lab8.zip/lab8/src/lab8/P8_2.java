package lab8;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class P8_2 {
    public static void main(String[] args) throws Exception {

        Scanner input = new Scanner(System.in);

        System.out.print("namn på fil att läsa från: ");
        String inNamn = input.nextLine();

        System.out.print("namn på fil att skriva till: ");
        String utNamn = input.nextLine();

        Scanner las = new Scanner(new File(inNamn));
        FileWriter skriv = new FileWriter(utNamn);

        int rad = 1;

        while (las.hasNextLine()) {

            String text = las.nextLine();

            skriv.write("/* " + rad + " */ " + text + "\n");

            rad++;
        }
        las.close();
        skriv.close();

        System.out.println("Läst " + (rad - 1) + " rader från filen " 
                + inNamn + " och skrivit till filen " + utNamn);
    }
}