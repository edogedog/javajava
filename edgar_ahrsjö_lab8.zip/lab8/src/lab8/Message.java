package lab8;

public class Message {
	private int nbrOfRows;
	private MessageRow[] rows;

	public Message(int maxRows) {
		nbrOfRows = 0;
		rows = new MessageRow[maxRows];
		
	}

	public void addRow(MessageRow row) {
		if (nbrOfRows >= rows.length) {
		    throw new IllegalStateException("arrayen är full");
		}
		rows[nbrOfRows] = row;
		nbrOfRows++;
	}
	public String getText() {
		return "";
	}
	public int getNbrOfRows(){
		return nbrOfRows;
	}
	public int getNbrOfWords(){
	    int total = 0;

	    for (int i = 0; i < nbrOfRows; i++) {
	        total += rows[i].getNbrOfWords();
	    }

	    return total;
	}
	public int getNbrOfChars(){
	    int total = 0;

	    for (int i = 0; i < nbrOfRows; i++) {
	        total += rows[i].getNbrOfChars();
	    }

	    return total;
	}
}

