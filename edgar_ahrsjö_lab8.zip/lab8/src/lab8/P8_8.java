package lab8;

import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.Scanner;

public class P8_8 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Ange URL:");
        String url = sc.nextLine();

        System.out.println("Ange filnamn:");
        String filnamn = sc.nextLine();

        try {
            InputStream in = new URL(url).openStream();

            Files.copy(in, Paths.get(filnamn),
                    StandardCopyOption.REPLACE_EXISTING);

            in.close();
            System.exit(0);

        } catch (Exception e) {
            System.out.println("Fel: " + e.getMessage());
            System.exit(1);
        }
    }
}