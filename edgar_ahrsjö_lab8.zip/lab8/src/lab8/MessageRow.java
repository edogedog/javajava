package lab8;

public class MessageRow {
private String text;

private int nbrOfWords;

private int nbrOfChars;
	
	public MessageRow(String x) {
		text = x;
		nbrOfWords = 0;
		if(!text.isBlank()){
			nbrOfWords = text.trim().split("\\s+").length;
		}
		nbrOfChars = text.length();
		
	}
	public String getText() {
		return text;
	}
	public int getNbrOfWords() {
		return nbrOfWords;
	}
	public int getNbrOfChars() {
		return nbrOfChars;
	}
}
