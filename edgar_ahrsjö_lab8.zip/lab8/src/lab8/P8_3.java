package lab8;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class P8_3 {
    public static void main(String[] args) throws Exception {

    	String inNamn = null;
    	String utNamn = null;
    	Scanner input = new Scanner(System.in);

    	if (args.length == 0) {
    	 System.out.print("läsa från");
    	 inNamn = input.nextLine();
    	 System.out.print("skriva till");
    	 utNamn = input.nextLine();
    	}
    	else if (args.length == 3) {
    	 System.out.println("Fil att skriva till: ");
    	 System.exit(1);
         return;	
    	}
    	else {
        inNamn = args[0];
        utNamn = args[1];
    	}
    	
        Scanner las = new Scanner(new File(inNamn));
        FileWriter skriv = new FileWriter(utNamn);
    	
        int rad = 1;
        while (las.hasNextLine()) {
            String text = las.nextLine();
            skriv.write("/* " + rad + " */ " + text + "\n");
            rad++;
        }
        las.close();
        skriv.close();

        System.out.println("Läst " + (rad - 1) + " rader från filen " 
                + inNamn + " och skrivit till filen " + utNamn);
    	}
    }
