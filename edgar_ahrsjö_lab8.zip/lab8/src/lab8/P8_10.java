package lab8;

import java.io.*;

import java.util.*;

public class P8_10 {

    public static void main(String[] args) {
      
    	Scanner sc = new Scanner(System.in);

        
        System.out.println("Ange infil:");
        File input = new File(sc.nextLine());

        System.out.println("Ange utfil:");
       
        File output = new File(sc.nextLine());

        File keyword = new File("JavaKeywords.csv");

        try {
            buildHtmlPage(input, output, keyword);
            System.exit(0);

        } catch (Exception e) {
            System.out.println("Fel: " + e.getMessage());
            System.exit(1);
        }
    }

    public static void buildHtmlPage(File input, File output, File keyword)
            throws FileNotFoundException {

       
    	Scanner fil = new Scanner(input);
      
        Scanner ord = new Scanner(keyword);
       
        PrintWriter ut = new PrintWriter(output);

        String[] keywords = ord.nextLine().split(",");

        fil.useDelimiter("\\A");
        String text = fil.hasNext() ? fil.next() : "";

       
        text = text.replace("&", "&amp;");
        
        text = text.replace("<", "&lt;");
       
        text = text.replace(">", "&gt;");

        for (String word : keywords) {
            text = text.replaceAll("\\b" + word + "\\b",
                    "<strong>" + word + "</strong>");
        }

        ut.println("<html>");
        ut.println("<body>");
        ut.print("<pre>");
        ut.print(text);
        ut.println("</pre>");
        ut.println("</body>");
        ut.println("</html>");

        fil.close();
        ord.close();
        ut.close();
    }
}