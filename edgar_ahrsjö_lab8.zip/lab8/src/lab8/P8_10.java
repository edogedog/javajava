package lab8;

public class P8_10 {

}
