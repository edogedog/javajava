
package lab8;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import java.io.FileNotFoundException;

public class P8_7 {
    public static void main(String[] args) throws Exception {

        Scanner input = new Scanner(System.in);
        System.out.print("Ange filnamn: ");

        String in = input.nextLine();
        File fileObject = new File(in);

        Message msg = new Message(10);

        Scanner fileScan;

        try {
            fileScan = new Scanner(fileObject);
        } catch (FileNotFoundException e) {
            System.out.println("den filen verkar inte finnas");
            System.exit(1);
            return;
        }

        // Kontrollera om filen slutar med radbrytning
        String original = java.nio.file.Files.readString(fileObject.toPath());
        String newline = original.contains("\r\n") ? "\r\n" : "\n";
        boolean endsWithNewline = original.endsWith("\n");

        while (fileScan.hasNextLine()) {
            String rad = fileScan.nextLine();

            MessageRow row = new MessageRow(rad);
            msg.addRow(row);
        }

        fileScan.close();

        msg.reverseRows();

        // Skriv tillbaka till samma fil
        FileWriter writer = new FileWriter(fileObject);

        for (int i = 0; i < msg.getNbrOfRows(); i++) {
            // Skriv raderna via Message.getText()
        }

        String result = msg.getText();

        // Bevara filens ursprungliga sista radbrytning
        if (!endsWithNewline && result.endsWith("\n")) {
            result = result.substring(0, result.length() - 1);
        }

        if (newline.equals("\r\n")) {
            result = result.replace("\n", "\r\n");
        }

        writer.write(result);
        writer.close();

        System.out.printf("rad: %d%n", msg.getNbrOfRows());
        System.out.printf("ord: %d%n", msg.getNbrOfWords());
        System.out.printf("bokstäver: %d%n", msg.getNbrOfChars());

        System.exit(0);
    }
}
