package lab8;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class P8_1 {
    public static void main(String[] args) throws Exception {

        File fil = new File("hello.txt");

        // öppna för att skriva
        FileWriter skriv = new FileWriter(fil);
        skriv.write("Hello, World!");

        // stäng filen
        skriv.close();

        // öppna fil
        Scanner las = new Scanner(fil);

        // läs och printa
        System.out.println(las.nextLine());

        // stäng igen
        las.close();
    }
}