package lab8;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;
import java.io.FileNotFoundException;


public class P8_5 {
    public static void main(String[] args) throws Exception {
    	
        // Fråga efter filnamnet, öppna filen och anropa metoden.

    	// skapa kod för att läsa in ett filnamn
    	Scanner input = new Scanner(System.in); // Läser från tangentbordet
    	System.out.print("Ange filnamn: ");
    	
  	
    	
    	String in = input.nextLine();           // Sparar namnet du skriver
    	
    	File fileObject = new File(in);

    	
    	try {
        	Scanner fileScan = new Scanner(fileObject);
    	} catch (FileNotFoundException e) {
    		System.out.println("den filen verkar inte finnas");
    		System.exit(1);
    	}
    	Scanner fileScan = new Scanner(fileObject); 
    	
    	int rowcount = 0;
    	int charcount = 0;
    	int wordcount = 0;
    	while (fileScan.hasNextLine()) {
    		rowcount ++;
    		String rad = fileScan.nextLine();
    		charcount += rad.length();
    		wordcount += rad.split("\\s+").length;
    	}
    	System.out.printf("rad: %d%n",rowcount);
    	System.out.printf("ord: %d%n",wordcount);
    	System.out.printf("bokstäver: %d%n",charcount);
    	System.exit(0);


  
    }
    	 
    	
    	 
    	
    }
