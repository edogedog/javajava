/**
 * 
 */
/**
 * 
 */
module lab8 {
}