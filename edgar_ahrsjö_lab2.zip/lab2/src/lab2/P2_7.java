package lab2;

import java.util.Scanner;

public class P2_7 {
    public static void main(String[] args) {

        Scanner skanner = new Scanner(System.in);

        System.out.print("Mata in första tid (på 'militärformat'): ");
        int tid1 = skanner.nextInt();

        System.out.print("Mata in andra tid (på 'militärformat'): ");
        int tid2 = skanner.nextInt();

        int skillnad = (tid2 / 100 * 60 + tid2 % 100)
                      - (tid1 / 100 * 60 + tid1 % 100);

        skillnad = (skillnad + 1440) % 1440;

        System.out.println(skillnad / 60 + " timmar och " + skillnad % 60 + " minuter");

        skanner.close();
    }
}