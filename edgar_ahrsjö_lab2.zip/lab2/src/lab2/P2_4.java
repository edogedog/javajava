package lab2;

import java.util.Scanner;

/*
 * P2_4
Skriv ett program som frågar användaren efter en radie och sedan skriver ut:
o Arean och omkretsen på en cirkel med den radien
o Volymen och ytan på ett klot med den radien
Mata in ett heltal: 2
Mata in ett till heltal: 5
Summan: 7
Differens: -3
Produkt: 10
Medel: 3.5
Distans: 3
Max: 5
Min: 2
Mata in ett heltal: 2
Mata in ett till heltal: 5
Summa: 7
Differens -3
Produkt 10
Medel: 3,50
Distans: 3
Max: 5
Min: 2
Codegrade försöker ignorera text för inmatning och letar sedan efter rätt svar (ned till 2
decimalers noggrannhet) i slutet av en egen rad. Så svaren skall stå på fyra egna rader.
Observera att programmet skall kunna hantera flyttal (double) både som inmatning och
svar.
 */
public class P2_4 {
	public static void main(String[] args) {
		
		Scanner skanner = new Scanner(System.in);
		System.out.print("Mata in en radie: ");
		double radie = skanner.nextDouble();
		

		
		skanner.close();
		
		
		
		System.out.printf("Cirkelarea: %.2f%n" , (long)((Math.PI * radie * radie )*100)/100.0);
		System.out.printf("Cirkelomkrets: %.2f%n", (long)((Math.PI * 2*(radie))*100)/ 100.0);
		System.out.printf("Klotvolym: %.2f%n", (long)(((4*Math.PI*radie*radie*radie)/3)* 100) /100.0);
		System.out.printf("Klotarea: %.2f%n", (long)((4*Math.PI*radie*radie) * 100) / 100.0);
		
	
		
		
	}

}
