package lab2;

import java.util.Scanner;

public class P2_5 {
	public static void main(String[] args) {
		
		Scanner skanner = new Scanner(System.in);
		System.out.print("Mata in en rektangelns bas: ");
		double bas = skanner.nextDouble();
		System.out.print("Mata in en rektangelns höjd: ");
		double höjd = skanner.nextDouble();

		
		skanner.close();
		
		
		
		System.out.printf("Arean är: %.3f%n", bas*höjd);
		System.out.printf("Omkretsen är: %.3f%n", 2 * (bas + höjd));
		System.out.printf("Diagonalen är: %.3f%n" , Math.sqrt(bas*bas+höjd*höjd));
		
	
		
		
	}

}