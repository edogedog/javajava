package lab2;

import java.util.Scanner;

public class P2_3 {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.print("Mata in ett heltal: ");
		int heltal1 = input.nextInt();
		
		System.out.print("Mata in ett till heltal: ");
		int heltal2 = input.nextInt();
		input.close();
		
		
		
		int summa = heltal1 + heltal2;
		System.out.printf(  "Summa:     %6d",summa);
		System.out.printf("%nDifferens: %6d",heltal1 - heltal2);
		System.out.printf("%nProdukt:   %6d",heltal1*heltal2);
		System.out.printf("%nMedel:     %9.2f", summa/2.0);
		System.out.printf("%nDistans:   %6d",Math.abs(heltal1-heltal2));
		System.out.printf("%nMax:       %6d",Math.max(heltal1,heltal2));
		System.out.printf("%nMin:       %6d", Math.min(heltal1,heltal2));
		
	
		
		
		
		
		
	}

}
