package lab2;

import java.util.Scanner;

public class P2_2 {
	public static void main(String[] args) {
		
		Scanner skanner = new Scanner(System.in);
		System.out.println("Mata in ett heltal: ");
		int heltal1 = skanner.nextInt();
		
		System.out.println("Mata in ett heltal: ");
		int heltal2 = skanner.nextInt();
		skanner.close();
		
		
		
		int summa = heltal1 + heltal2;
		
		System.out.println("Summan: " + summa);
		System.out.println("Differens: " + (heltal1 - heltal2));
		System.out.println("Produkt: " + heltal1*heltal2);
		System.out.println("Medel: " + summa/2.0);
		System.out.println("Distans: " + Math.abs(heltal1 - heltal2));
		System.out.println("Max: " + Math.max(heltal1,heltal2));
		System.out.print("Min: " + Math.min(heltal1,heltal2));
		
	
		
		
		
	}

}


/*
 * 
 * P2_2
Skriv ett program som frågar användaren efter två heltal och sedan skriver ut:
Summan
Differensen
Produkten
Medelvärdet
Distansen (absolutbeloppet av differensen)
Största värdet
Minsta värdet
 
Tips: metoderna abs, min och max finns i matteklassen (Math) och även round (om ni
behöver heltal som svar) då min och max faktiskt returnerar ett flyttal även om man skickar
in heltal.

*/