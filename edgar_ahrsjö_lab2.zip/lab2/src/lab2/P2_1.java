package lab2;

import java.util.Scanner;

public class P2_1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Mata in ett heltal: " );
		int siffran = input.nextInt();
		input.close();
		
		System.out.println("Kvadraten är: " + siffran*siffran);
		System.out.println("Kubiken är: " + Math.round(Math.pow(siffran, 3)));
		System.out.println("Talet upphöjt till fyra är: " + Math.round(Math.pow(siffran, 4)));
		
	}

}
