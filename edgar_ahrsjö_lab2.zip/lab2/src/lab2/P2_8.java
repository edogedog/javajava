package lab2;

import java.util.Scanner;

public class P2_8 {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Mata in ett månadsnummer: ");
		int nummer = input.nextInt();
		String[] list = {"Januari","Februari","Mars","April","Maj","Juni","Juli","Augusti","September","Oktober","November","December"};
		
		System.out.println(list[nummer-1]);
	}
		
	}