package lab2;

import java.util.Scanner;

public class P2_6 {
	public static void main(String[] args) {
		
		Scanner skanner = new Scanner(System.in);
		System.out.print("Mata in ett heltal mellan 1 000 och 999 999: ");
		String heltal = skanner.next();
		String heltal2 = skanner.next();
		
		System.out.print(heltal+heltal2);
	}
}
		
		
		
	

	