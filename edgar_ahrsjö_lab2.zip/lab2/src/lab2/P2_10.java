package lab2;

import java.util.Scanner;

public class P2_10 {
    public static void main(String[] args) {

        Scanner skanner = new Scanner(System.in);

        System.out.print("Mata in första partikelns laddning: ");
        int q1 = skanner.nextInt();

        System.out.print("Mata in andra partikelns laddning: ");
        int q2 = skanner.nextInt();

        System.out.print("Mata in avståndet i meter: ");
        int r = skanner.nextInt();

        double e = 8.854e-12;

        double svar = (q1 * q2) / (4 * Math.PI * e * r * r);

        System.out.printf("Elektriska kraften är: %.1f Newton", (double)Math.round(svar));

        skanner.close();
    }
}
