package lab2;

import java.util.Scanner;

public class P2_9 {
	public static void main(String[] args) {
		
		Scanner skanner = new Scanner(System.in);
		System.out.print("Mata in R1's resistans: ");
		float r1 = skanner.nextFloat();
		System.out.print("Mata in R2's resistans: ");
		float r2 = skanner.nextFloat();
		System.out.print("Mata in R3's resistans: ");
		float r3 = skanner.nextFloat();
		float par = r1 + ((r2*r3)/(r2+r3));
		System.out.print("Total resistansen är: " + (par));
		
		
	
	
		
		
		}
	}