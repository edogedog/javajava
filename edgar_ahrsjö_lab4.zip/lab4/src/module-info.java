/**
 * 
 */
/**
 * 
 */
module Lab4 {
}