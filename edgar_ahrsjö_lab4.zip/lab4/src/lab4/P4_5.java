package lab4;

public class P4_5 {

    public static void main(String[] args) {
        TallyCounter1 tally = new TallyCounter1();
        int val = 0;
        tally.count();
        val = tally.getValue();
        System.out.println("count");
        System.out.println(val);
        
        tally.count();
        val = tally.getValue();
        System.out.println("count");
        System.out.println(val);
        
        tally.count();
        val = tally.getValue();
        System.out.println("count");
        System.out.println(val);
        
        tally.undo();
        val = tally.getValue();
        System.out.println("undo");
        System.out.println(val);
        
        tally.reset();
        val = tally.getValue();
        System.out.println("reset");
        System.out.println(val);
        
        
       
    }
}