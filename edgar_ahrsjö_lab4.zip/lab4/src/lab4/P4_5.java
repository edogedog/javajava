package lab4;

public class P4_5 {

    public static void main(String[] args) {
        TallyCounter2 tally = new TallyCounter2();
        int val = 0;
        int limit = 3;
        String word = "nothing";
        tally.count();
        
        val = tally.getValue();
        word = tally.getWord();
        System.out.println("count");
        System.out.println(word);
        System.out.println(val);
        
        tally.count();
        val = tally.getValue();
        word = tally.getWord();
        System.out.println("count");
        System.out.println(word);
        System.out.println(val); 
        
        tally.count();
        val = tally.getValue();
        word = tally.getWord();
        System.out.println("count");
        System.out.println(word);
        System.out.println(val);
        
        tally.undo();
        val = tally.getValue();
        word = tally.getWord();
        System.out.println("undo");
        System.out.println(word);
        System.out.println(val);
        
        tally.undo();
        val = tally.getValue();
        word = tally.getWord();
        System.out.println("undo");
        System.out.println(word);
        System.out.println(val);
        
        
   
        
        tally.setLimit(limit);
        val = tally.getValue();
        word = tally.getWord();
        System.out.println("limit becomes "+limit);
        System.out.println(word);
        System.out.println(val);
        
        tally.count();
        val = tally.getValue();
        word = tally.getWord();
        System.out.println("count");
        System.out.println(word);
        System.out.println(val); 
        
        tally.count();
        val = tally.getValue();
        word = tally.getWord();
        System.out.println("count");
        System.out.println(word);
        System.out.println(val);
        
        tally.count();
        val = tally.getValue();
        word = tally.getWord();
        System.out.println("count");
        System.out.println(word);
        System.out.println(val);
        
        tally.undo();
        val = tally.getValue();
        word = tally.getWord();
        System.out.println("undo");
        System.out.println(word);
        System.out.println(val);
        
        
        tally.reset();
        val = tally.getValue();
        word = tally.getWord();
        System.out.println("reset");
        System.out.println(word);
        System.out.println(val);
        
        
        
       
    }
}