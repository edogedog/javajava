package lab4;

public class TallyCounter2 {
	
	private int counter;
	private int limit;
	
	public TallyCounter2() {
		
		counter = 0;
		limit = Integer.MAX_VALUE;

	}
	
	public void count() {counter += 1;	}
	
	public int getValue() {return counter;}
	
	public void reset() {counter = 0;}
	public void undo() {
		if (counter != 0 && !(counter >= limit))
		{
		counter -=1;
		}
		}
	public void setLimit(int)

	
}