package lab4;

public class TallyCounter2 {
	
	private int counter;
	private int limit;
	private String word;
	
	public TallyCounter2() {
		
		counter = 0;
		limit = Integer.MAX_VALUE;
		word = "";

	}
	
	public void count() {
		if (counter == limit) {
			word = "Limit reahced cant add more";	
			}
		else if (counter == limit-1) {
			word = "limit reahced";
			counter += 1;
			}
		else if (counter == limit-2) {
			word = "Warning limit almost reached";
			counter += 1;
			}
		else {
			word ="adding";
			counter += 1;	
			}
		}
		
	public int getValue() {
		return counter;
		}
	public String getWord() {
		return word;
		}
	
	public void reset() {
		word = "reseting count";
		counter = 0;
		}
	public void undo() {
		if (counter != 0) {
			word = "count will be reduced by 1";
			counter -= 1;
			}
		}
		
	public void setLimit(int limitv) {
		word = "new limit for count";
		limit = limitv;
			}
		}

	
