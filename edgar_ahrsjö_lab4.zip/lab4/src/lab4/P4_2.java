package lab4;

public class P4_2 {

    public static void main(String[] args) {
        CheckString text = new CheckString("Hejsan");

        System.out.println("Text: " + text.getString());
        System.out.println("Mitten: " + text.middle());
        System.out.println("Antal vokaler: " + text.countVowels());
    }
}