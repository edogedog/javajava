package lab4;

public class CheckNumber {
	
		private double number1;
		private double number2;
		private double number3;
		
		public CheckNumber() {
	    }

	    public void setNbr1(double number) {
	        number1 = number;
	    }

	    public void setNbr2(double number) {
	        number2 = number;
	    }

	    public void setNbr3(double number) {
	        number3 = number;
	    }

	    public boolean allTheSame() {
	        return number1 == number2 && number2 == number3;
	    }

	    public boolean allDifferent() {
	        return number1 != number2 &&
	               number1 != number3 &&
	               number2 != number3;
	    }

	    public boolean isSorted() {
	        boolean increasing =
	                number1 <= number2 && number2 <= number3;

	        boolean decreasing =
	                number1 >= number2 && number2 >= number3;

	        return increasing || decreasing;
	    }
}
