package lab4;

public class P4_3 {

    public static void main(String[] args) {
        SodaCan burk = new SodaCan(12, 3);

        System.out.println("Höjd: " + burk.getHeight());
        System.out.println("Radie: " + burk.getRadius());
        System.out.println("Volym: " + burk.getVolume());
        System.out.println("Total ytarea: " + burk.getSurfaceArea());
        System.out.println("Bottenarea: " + burk.getBottomArea());
        System.out.println("Omkrets: " + burk.getCircumference());
    }
}