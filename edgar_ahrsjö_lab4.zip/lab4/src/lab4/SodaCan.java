package lab4;

public class SodaCan {

    private double height;
    private double radius;
    
    public SodaCan(double height, double radius) {
    	this.height = height;
    	this.radius = radius;
    	
    }
    
    public double getHeight() {
    	return height;
    	
    }
    public double getRadius() {
    	return radius;
    }
    public double getVolume() {
    	return Math.PI * radius * radius * height;
    }
    
    public double getSurfaceArea() {
    	return 2 * getBottomArea() + getCircumference() * height;  
    	
    }
    
    public double getBottomArea() {
    	return Math.PI * radius * radius;
    	
    }
    public double getCircumference() {
    	return 2 * Math.PI * radius;
    }
}