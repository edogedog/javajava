package lab4;

public class TallyCounter1 {
	
	private int counter;
	
	public TallyCounter1() {
		
		counter = 0;

	}
	
	public void count() {counter += 1;	}
	
	public int getValue() {return counter;}
	
	public void reset() {counter = 0;}
	public void undo() {
		if (counter != 0)
		{
		counter -=1;
		}
		}

	
}