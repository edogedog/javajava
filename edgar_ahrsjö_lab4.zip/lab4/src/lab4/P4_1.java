package lab4;

import java.util.Scanner;

public class P4_1 {
	public static void main(String[] args) {
		CheckNumber cn = new CheckNumber();
		cn.setNbr1(3.14);
		cn.setNbr2(2.78);
		cn.setNbr3(1.0);
		System.out.printf("Är alla lika? %b%n", cn.allTheSame());
		System.out.printf("Är alla olika? %b%n", cn.allDifferent());
		System.out.printf("Är talen sorterade? %b%n", cn.isSorted());
	}
}
