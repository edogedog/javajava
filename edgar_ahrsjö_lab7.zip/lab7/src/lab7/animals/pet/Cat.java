package lab7.animals.pet;

public class Cat extends Pet {

    private boolean indoor;
    
    public Cat(String a) {
    	super(a);	
    }
    public Cat(String a,int b) {
    	super(a,b);
    }
    public Cat(String a,int b, boolean c) {
    	super(a,b);
    	indoor = c;  
    }

    public String makeSound() {
    	return "Mjau mjau";
    }

    public String getDescription() {
    	return ("Katt namn"+ getName() + "age" + getAge() + "inomhus" + isIndoor());
    }
    public boolean isIndoor() {
    	return indoor;
    }
 
    
}
