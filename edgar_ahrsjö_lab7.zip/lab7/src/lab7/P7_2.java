package lab7;
public class P7_2 {

    public static void main(String[] args) {

        TallyCounterLimit counter = new TallyCounterLimit();
 

        System.out.println(counter.getValue());

        counter.count();
        counter.count();
        counter.count();

        System.out.println(counter.getValue());

        counter.undo();

        System.out.println(counter.getValue());

        counter.reset();

        System.out.println(counter.getValue());

        counter.undo();

        System.out.println(counter.getValue());
        
        counter.setLimit(1);
        
        counter.count();
        
 
        
        System.out.println(counter.getValue());
    }
}
