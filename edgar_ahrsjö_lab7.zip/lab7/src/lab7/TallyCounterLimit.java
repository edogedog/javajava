package lab7;

public class TallyCounterLimit extends TallyCounterUndo {
	private int limit = Integer.MAX_VALUE;
	
	public TallyCounterLimit() {		
	}
	public TallyCounterLimit(int input) {
		 if (0 > input) {
			 throw new IllegalArgumentException("för liten limit" +limit);
		 	}
		limit = input;
		
		
	}
	
	//överskuggande i guess
	public void count() {
		 if (this.counter >= limit) {
			 throw new IllegalStateException("den blev över limit "+limit);
		 	}
	        this.counter++;
	        
		
	}
	public void setLimit(int input) {
		limit = input;
	}

}
