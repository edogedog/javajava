package lab7;
public class P7_1 {

    public static void main(String[] args) {

        TallyCounterUndo counter = new TallyCounterUndo();

        System.out.println(counter.getValue());

        counter.count();
        counter.count();
        counter.count();

        System.out.println(counter.getValue());

        counter.undo();

        System.out.println(counter.getValue());

        counter.reset();

        System.out.println(counter.getValue());

        counter.undo();

        System.out.println(counter.getValue());
    }
}
