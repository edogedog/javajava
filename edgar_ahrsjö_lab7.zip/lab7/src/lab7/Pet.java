package lab7;
import java.time.LocalDate;

public class Pet {

    private String name = "nameless";
    private int birthYear = LocalDate.now().getYear();;
    
    public Pet(String a) {
    	if (a == null || a.isBlank()) {
    		throw new IllegalArgumentException("namnet är tomt pucko");
    	}
    	setName(a);	
    }
    public Pet(String a,int b) {
    	setName(a);
    	setBirthYear(b);  	
    }

    private void setName(String input) {
    	name = input;
    }

    private void setBirthYear(int input) {
    	birthYear = input;
    	if (birthYear > 2026) {
    		throw new IllegalArgumentException("för UNG");
    	}
    	birthYear = input;
    }
    public String getName() {
    	//isblank = good, better than isempty
    	if (name == null || name.isBlank()) {
    		throw new IllegalArgumentException("namnet är tomt pucko");
    	}
    	return name;
    }
    public int getAge() {
    	if (birthYear > 2026) {
    		throw new IllegalArgumentException("för UNG");
    	}
    	return (2026-birthYear);
    }
    
    
}
