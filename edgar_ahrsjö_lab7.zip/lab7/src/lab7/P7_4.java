package lab7;
public class P7_4 {

    public static void main(String[] args) {

        Dog dog = new Dog("bober",2020,true);
        System.out.println(dog.getAge());
        System.out.println(dog.getName());
        System.out.println(dog.getDescription());
        System.out.println(dog.isHunting());
        
        Cat dogg = new Cat("sven",2019,true);
        System.out.println(dogg.isIndoor());

 

    }
}
