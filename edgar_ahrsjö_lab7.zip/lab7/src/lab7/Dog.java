package lab7;

public class Dog extends Pet {

    private boolean hunting;
    
    public Dog(String a) {
    	super(a);	
    }
    public Dog(String a,int b) {
        super(a,b);	
    }
    public Dog(String a,int b, boolean c) {
    	super(a,b);
    	hunting = c;  
    }

    public String makeSound() {
    	return "Vov vov!";
    }

    public String getDescription() {
    	return ("Hund namn"+ getName() + "age" + getAge() + "huting" + isHunting());
    }
    public boolean isHunting() {
    	return hunting;
    }
 
    
}
