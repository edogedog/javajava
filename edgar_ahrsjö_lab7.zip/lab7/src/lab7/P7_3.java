package lab7;
public class P7_3 {

    public static void main(String[] args) {

        Pet dog = new Pet(null);
    

 

    }
}
