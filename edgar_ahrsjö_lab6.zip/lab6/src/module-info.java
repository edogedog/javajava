/**
 * 
 */
/**
 * 
 */
module lab6 {
}