package lab6;
import java.util.Random;

public class Yatzy2 {
	private Dice2[] dice;
	
	public Yatzy2(int... a) {
		if (a.length == 0) {
			a = new int[] {6,6,6,6,6};
		}
		dice = new Dice2[a.length];
		for (int i = 0; i < a.length; i++) {
		    try {
		        dice[i] = new Dice2(a[i]);
		    } catch (IllegalArgumentException e) {
		        throw new IllegalArgumentException("Ogiltigt värde på tärning nr " + (i + 1));
		    }
		}
		
	
	}
	public void roll() {
	    for (int i = 0; i < dice.length; i++) {
	        dice[i].roll();
	    }
	}
	public int getTotalValue() {
	    int sum = 0;

	    for (int i = 0; i < dice.length; i++) {
	     sum += dice[i].getValue();
	    }

	    return sum;
	}

	public String toString() {
	    String sum2 = "";
	
	    for (int i = 0; i < dice.length; i++) {
	     sum2 += "[" + dice[i].getValue() + "] ";
	    }
	
	    return sum2.trim();
	}	    
	
	class Dice2 {
		private int value;
		private Random randGenerator;
		private int nbrOfSides;
		
		public Dice2() {
			this(6);
			
		}
		public Dice2(int a ) {
			if (a == 4 || a == 6||a==8||a==10||a==12||a==20) {
				nbrOfSides = a;
				randGenerator = new Random();
			}
			else {
				throw new IllegalArgumentException("Ogilltigt antal sidore");
			}
			
		}
		public void roll() {
			value = randGenerator.nextInt(nbrOfSides) + 1;
			
		}
		public int getValue() {
			
			return(value);
			
		}
		public String toString() {
			return("["+value+"]");
		}
		
		
	}
	
}