package lab6;

public class SodaCanWithEx {
    private double height;
    private double radius;

    public SodaCanWithEx(double height, double radius) {
        if (height < 0)
            throw new IllegalArgumentException("Höjden får inte vara negativ: " + height);
        if (radius < 0)
            throw new IllegalArgumentException("Radien får inte vara negativ: " + radius);
        this.height = height;
        this.radius = radius;
    }

    public double getHeight() { return height; }
    public double getRadius() { return radius; }
    public double getVolume() { return Math.PI * radius * radius * height; }
    public double getSurfaceArea() { return 2 * getBottomArea() + getCircumference() * height; }
    public double getBottomArea() { return Math.PI * radius * radius; }
    public double getCircumference() { return 2 * Math.PI * radius; }
    public String middle() { return "Mitten ligger på höjden " + (height / 2); }
}