package lab6;

public class StaticUtilityMethods {

    private StaticUtilityMethods() {
    }

    public static int calculateSum(int a, int b) {
        return a + b;
    }

    public static double calculateSum(double a, double b) {
        return a + b;
    }

    public static int calculateSum(int a, int b, int c) {
        return calculateSum(a, calculateSum(b, c));
    }

    public static double calculateSum(double a, double b, double c) {
        return calculateSum(a, calculateSum(b, c));
    }
    //arrayyyy
    public static int calculateSum(int... list) {
    	int sum = 0;
    	int loopval;
    	int endval = list.length;
    	for (loopval = 0; loopval < endval; loopval++) {
    		sum += list[loopval];
    		
    	}
    	
    	return(sum);
    }
    //array för double
    public static double calculateSum(double... list) {
    	double sum = 0;
    	int loopval;
    	int endval = list.length;
    	for (loopval = 0; loopval < endval; loopval++) {
    		sum += list[loopval];
    		
    	}
    	
    	return(sum);
    }
    //2d array kan mman sääga
    public static int calculateSum(int[][] list) {
    	int sum = 0;
    	int rad;
    	int kol;
    	int endval = list.length;
    	for (rad = 0; rad < endval; rad++) {
    		for (kol = 0; kol < list[rad].length; kol++) {
        		sum += list[rad][kol];
        		
        	}
    		
    	}
    	
    	return(sum);
    }
    
}