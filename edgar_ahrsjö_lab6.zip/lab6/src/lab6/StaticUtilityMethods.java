package lab6;

import java.util.ArrayList;

public class StaticUtilityMethods {
    private StaticUtilityMethods() {}

    public static int calculateSum(int a, int b) { return a + b; }
    public static double calculateSum(double a, double b) { return a + b; }
    public static int calculateSum(int a, int b, int c) { return calculateSum(a, calculateSum(b, c)); }
    public static double calculateSum(double a, double b, double c) { return calculateSum(a, calculateSum(b, c)); }

    public static int calculateSum(int[] values) {
        int sum = 0;
        for (int v : values) sum += v;
        return sum;
    }

    public static double calculateSum(double[] values) {
        double sum = 0;
        for (double v : values) sum += v;
        return sum;
    }

    public static int calculateSum(int[][] values) {
        int sum = 0;
        for (int[] row : values) sum += calculateSum(row);
        return sum;
    }

    public static Boolean checkSweEmailAddress(String email) {
        if (email == null) return false;
        return email.matches("[^@\\s]+@[^@\\s]+\\.se");
    }

    public static Boolean checkEmailAddress(String email) { return checkSweEmailAddress(email); }

    public static String convertToCamelCase(String sentence) {
        if (sentence == null) return "";
        String trimmed = sentence.trim();
        if (trimmed.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String word : trimmed.split("\\s+")) {
            sb.append(Character.toUpperCase(word.charAt(0)));
            sb.append(word.substring(1).toLowerCase());
        }
        return sb.toString();
    }

    public static int[] merge(int[] a, int[] b) {
        int[] result = new int[a.length + b.length];
        int ia = 0, ib = 0, r = 0;
        while (ia < a.length || ib < b.length) {
            if (ia < a.length) result[r++] = a[ia++];
            if (ib < b.length) result[r++] = b[ib++];
        }
        return result;
    }

    public static String merge(String s1, String s2) {
        String[] a = splitWords(s1);
        String[] b = splitWords(s2);
        StringBuilder sb = new StringBuilder();
        int ia = 0, ib = 0;
        while (ia < a.length || ib < b.length) {
            if (ia < a.length) append(sb, a[ia++]);
            if (ib < b.length) append(sb, b[ib++]);
        }
        return sb.toString();
    }

    private static String[] splitWords(String s) {
        String t = (s == null) ? "" : s.trim();
        return t.isEmpty() ? new String[0] : t.split("\\s+");
    }

    private static void append(StringBuilder sb, String word) {
        if (sb.length() > 0) sb.append(' ');
        sb.append(word);
    }

    public static int[] integerFactorization(int n) {
        ArrayList<Integer> factors = new ArrayList<Integer>();
        for (int i = 2; i <= n / 2; i++) {
            if (n % i == 0) factors.add(i);
        }
        int[] result = new int[factors.size()];
        for (int i = 0; i < result.length; i++) result[i] = factors.get(i);
        return result;
    }

    public static int recursiveSum(int n) {
        if (n < 0) throw new IllegalArgumentException("Talet får inte vara negativt: " + n);
        if (n < 10) return n;
        return (n % 10) + recursiveSum(n / 10);
    }

    public static int recursiveCumulativeSum(int n) { return recursiveSum(n); }
}