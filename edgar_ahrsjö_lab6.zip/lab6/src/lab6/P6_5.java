package lab6;

import java.util.Arrays;

public class P6_5 {
    public static void main(String[] args) {
        int[] tests = {12, 21, 7, 36, 2, 100};
        for (int n : tests)
            System.out.println(n + " -> " + Arrays.toString(StaticUtilityMethods.integerFactorization(n)));
    }
}