package lab6;

public class P6_3 {
    public static void main(String[] args) {
        String[] emails = {"a@b.se", "a@bse", "aATb.se", "@b.se", "a@.se", "anna.s@foo.se", "a@b.com"};
        for (String e : emails)
            System.out.println("checkSweEmailAddress(\"" + e + "\") = " + StaticUtilityMethods.checkSweEmailAddress(e));
        System.out.println(StaticUtilityMethods.convertToCamelCase("Hejsan hoppsan fallerallera"));
        System.out.println(StaticUtilityMethods.convertToCamelCase("   hejsan   HOPPSAN \t fallerallera  "));
    }
}