package lab6;

public class P6_10 {
    public static void main(String[] args) {
        try {
            Yatzy2 hand = new Yatzy2(4, 6, 8, 10);
            hand.roll();

            System.out.println(hand);
            System.out.println("summan är" + hand.getTotalValue());
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }
    }
}