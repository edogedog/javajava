package lab6;

public class CarWithEx {
    private final double FUEL_TANK_VOLUME = 55.0;
    private double fuelLevel = 0.0;
    private double fuelPer10Km = 0.0;

    public CarWithEx() { this(0.5); }

    public CarWithEx(double fuelEfficiency) {
        if (fuelEfficiency < 0)
            throw new IllegalArgumentException("Bränsleförbrukningen får inte vara negativ: " + fuelEfficiency);
        fuelPer10Km = fuelEfficiency;
    }

    public double getFuelLevel() { return fuelLevel; }

    public void addFuel(double liters) {
        if (liters < 0)
            throw new IllegalArgumentException("Kan inte tanka negativ mängd: " + liters);
        if (fuelLevel + liters > FUEL_TANK_VOLUME)
            throw new IllegalArgumentException("Tanken rymmer bara " + FUEL_TANK_VOLUME + " liter");
        fuelLevel += liters;
    }

    public void drive(double km) {
        if (km < 0)
            throw new IllegalArgumentException("Kan inte köra en negativ sträcka: " + km);
        double needed = fuelPer10Km * km / 10.0;
        if (needed >= fuelLevel)
            fuelLevel = 0.0;
        else
            fuelLevel -= needed;
    }
}