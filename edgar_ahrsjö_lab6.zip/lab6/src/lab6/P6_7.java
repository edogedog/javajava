package lab6;

public class P6_7 {
    public static void main(String[] args) {
        CarWithEx car = new CarWithEx();
        car.addFuel(20);
        car.drive(100);
        System.out.println("Bränsle kvar: " + car.getFuelLevel());
        try {
            car.addFuel(-5);
        } catch (IllegalArgumentException e) {
            System.out.println("Fångade: " + e.getMessage());
        }
        try {
            car.addFuel(100);
        } catch (IllegalArgumentException e) {
            System.out.println("Fångade: " + e.getMessage());
        }
        car.drive(100000);
        System.out.println("Bränsle efter lång körning: " + car.getFuelLevel());
        try {
            new CarWithEx(-1);
        } catch (IllegalArgumentException e) {
            System.out.println("Fångade: " + e.getMessage());
        }
    }
}