package lab6;

import java.util.Arrays;

public class P6_4 {
    public static void main(String[] args) {
        System.out.println(Arrays.toString(StaticUtilityMethods.merge(new int[]{1, 3, 5}, new int[]{2, 4, 6})));
        System.out.println(Arrays.toString(StaticUtilityMethods.merge(new int[]{1, 3, 5, 7, 9}, new int[]{2, 4})));
        System.out.println(StaticUtilityMethods.merge("Hej hur mår du", "det är toppen idag"));
        System.out.println(StaticUtilityMethods.merge("  Hej   hur mår du ", "det är   toppen idag och mer"));
    }
}