package lab6;
import java.util.Random;

public class Dice2 {
	private int value;
	private Random randGenerator;
	private int nbrOfSides;
	
	public Dice2() {
		this(6);
		
	}
	public Dice2(int a ) {
		if (a == 4 || a == 6||a==8||a==10||a==12||a==20) {
			nbrOfSides = a;
			randGenerator = new Random();
		}
		else {
			throw new IllegalArgumentException("Ogilltigt antal sidore");
		}
		
	}
	public void roll() {
		value = randGenerator.nextInt(nbrOfSides) + 1;
		
	}
	public int getValue() {
		
		return(value);
		
	}
	public String toString() {
		return("["+value+"]");
	}
	
	
}