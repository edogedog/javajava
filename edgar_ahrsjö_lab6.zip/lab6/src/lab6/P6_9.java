package lab6;

public class P6_9 {
    public static void main(String[] args) {
    	Dice2 d6 = new Dice2(10);
    	d6.roll();
    	System.out.println(d6);
    	

 
    }
}
