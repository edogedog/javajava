package lab6;

public class P6_2 {

    public static void main(String[] args) {

        System.out.println(StaticUtilityMethods.calculateSum(2, 3));
        System.out.println(StaticUtilityMethods.calculateSum(2, 3, 4));

        System.out.println(StaticUtilityMethods.calculateSum(2.5, 3.5));
        System.out.println(StaticUtilityMethods.calculateSum(2.5, 3.5, 4.5));

        // Blandning av int och double använder double-metoden.
        System.out.println(StaticUtilityMethods.calculateSum(2, 3.5));
        
        
        
        
        int[] heltal = {2, 1, 4};
        double[] decimal = {2.5, 3.222, 4.25};
        //2d array kan ,am typ säga att vi gör här längst ner, mycket praktisk lärdom fatkist
        int[][] tabell = {{1, 2, 3}, {4, 5}};

        System.out.println( StaticUtilityMethods.calculateSum(heltal));
        System.out.println(StaticUtilityMethods.calculateSum(decimal));
        System.out.println(StaticUtilityMethods.calculateSum(tabell));
    }
}