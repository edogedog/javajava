package lab6;

public class P6_8 {
    public static void main(String[] args) {
        int[] tests = {0, 5, 10, 1234, 999999999};
        for (int n : tests)
            System.out.println("recursiveSum(" + n + ") = " + StaticUtilityMethods.recursiveSum(n));
        try {
            StaticUtilityMethods.recursiveSum(-12);
        } catch (IllegalArgumentException e) {
            System.out.println("Fångade: " + e.getMessage());
        }
    }
}