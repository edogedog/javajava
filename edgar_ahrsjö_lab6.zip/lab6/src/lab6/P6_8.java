package lab6;

public class P6_8 {

}
