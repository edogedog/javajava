package lab6;

public class P6_1 {

    public static void main(String[] args) {

        System.out.println(StaticUtilityMethods.calculateSum(2, 3));
        System.out.println(StaticUtilityMethods.calculateSum(2, 3, 4));

        System.out.println(StaticUtilityMethods.calculateSum(2.5, 3.5));
        System.out.println(StaticUtilityMethods.calculateSum(2.5, 3.5, 4.5));

        // Blandning av int och double använder double-metoden.
        System.out.println(StaticUtilityMethods.calculateSum(2, 3.5));
    }
}