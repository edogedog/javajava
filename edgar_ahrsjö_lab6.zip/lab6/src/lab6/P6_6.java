package lab6;

public class P6_6 {
    public static void main(String[] args) {
        SodaCanWithEx can = new SodaCanWithEx(12.0, 3.0);
        System.out.println("Volym: " + can.getVolume() + ", yta: " + can.getSurfaceArea());
        try {
            new SodaCanWithEx(-1.0, 3.0);
        } catch (IllegalArgumentException e) {
            System.out.println("Fångade: " + e.getMessage());
        }
        try {
            new SodaCanWithEx(10.0, -2.0);
        } catch (IllegalArgumentException e) {
            System.out.println("Fångade: " + e.getMessage());
        }
    }
}