package lab3;

import java.util.Scanner;

public class P3_10 {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		int tal = input.nextInt();
		String temp = "";
		
		if (tal == 0)
		{
			temp = "0";
		}
		
		while (tal > 0)
		{
			if (tal % 2 == 0)
			{
				temp = "0" + temp;
			}
			else
			{
				temp = "1" + temp;
			}
			
			tal = tal / 2;
		}
		
		System.out.println(temp);
	}
}
