package lab3;

import java.util.Scanner;

public class P3_10 {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		System.out.print("Skriv ditt tal: ");
		int tal = input.nextInt();
		boolean udda = 0;
		String temp = "";
		
		if(tal%2 == 1 || 0) {
			temp = temp
			udda = true;
		}
		tal = tal/2;
		
		
		

		
		for (int i = namn.length() -1; i >= 0; i--) {
			namn2 = namn2 + namn.charAt(i);
		}
		System.out.println("Ditt namn baklänges är: ");
		System.out.println(namn2);

		
	}

}