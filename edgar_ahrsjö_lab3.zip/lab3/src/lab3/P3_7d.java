package lab3;

import java.util.Scanner;

public class P3_7d {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		System.out.print("Skriv en tal serie: ");
		
		int tal = input.nextInt();
		int min = tal;
		int max = tal;
		int temp = 0;
		int odd = 0;
		int even = 0;
		int summa = 0;
		int släppande = tal;
		
		String resultat = "";
		String dubbelresultat = "";
		
		int antalSamma = 1;
		
		while (tal != 0) {
			
			if (tal > max)
			{
				max = tal;
			}
			else if (tal < min)
			{
				min = tal;
			}
			
			temp = tal % 2;
			
			if (temp == 0)
			{
				even++;
			}
			else
			{
				odd++;
			}
			
			summa += tal;
			resultat += summa + " ";
			
			släppande = tal;
			tal = input.nextInt();
			
			if (tal == släppande && tal != 0)
			{
				antalSamma++;
				
				if (antalSamma % 2 == 0)
				{
					dubbelresultat += tal + " ";
				}
			}
			else
			{
				antalSamma = 1;
			}
		}
		
		System.out.println("min och max: " + min + " " + max);
		System.out.println("even och odd: " + even + " " + odd);
		System.out.println(resultat);
		System.out.println(dubbelresultat);
	}
}
