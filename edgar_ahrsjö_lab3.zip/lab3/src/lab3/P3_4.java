package lab3;

import java.util.Scanner;

public class P3_4 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Mata in en temperatur: ");
		double temp = input.nextDouble();
		String tempunit = input.next();
		
		System.out.print("Mata in en höjd: ");
		double height = input.nextDouble();
		String heightunit = input.next();
		
		String svar = "jag vet inte";
		
		if(tempunit.equals("F"))
		{
			temp = (temp-32)*5/9; 
		}
		if(heightunit.equals("f"))
		{
			height = height*0.3048;
		}
		
		double kokpunkt = 100 - (height/300);
		if(temp < 0)
		{
			svar = "is";
		}
		else if(temp>=0&&temp<kokpunkt)
		{
			svar = "flytande";
		}
		else if(temp>=kokpunkt)
		{
			svar = "gas";
		}
		System.out.print(svar);
		
		
	}

}
