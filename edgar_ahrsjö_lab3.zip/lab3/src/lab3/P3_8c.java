package lab3;

import java.util.Scanner;

public class P3_8c {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		System.out.print("Var god ange en textsträng: ");
		String inputString = input.nextLine();
		
		String vokaler = "aouåeiyäöAOUÅEIYÄÖ";
		
		for (int i = 0; i < inputString.length(); i++)
		{
			if (vokaler.contains(String.valueOf(inputString.charAt(i))))
			{
				System.out.print("_");
			}
			else
			{
				System.out.print(inputString.charAt(i));
			}
		}
	}
}