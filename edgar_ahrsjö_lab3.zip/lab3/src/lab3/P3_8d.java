package lab3;

import java.util.Scanner;

public class P3_8d {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		System.out.print("Var god ange en textsträng: ");
		String inputString = input.nextLine();
		
		String vokaler = "aouåeiyäöAOUÅEIYÄÖ";
		int antal = 0;
		
		for (int i = 0; i < inputString.length(); i++)
		{
			if (vokaler.contains(String.valueOf(inputString.charAt(i))))
			{
				antal++;
			}
		}
		
		System.out.println("Antal vokaler är: " + antal);
	}
}