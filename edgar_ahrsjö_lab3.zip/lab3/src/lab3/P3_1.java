package lab3;

import java.util.Scanner;

public class P3_1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Mata in ett heltal negativt positivt eller noll: ");
		int heltal = input.nextInt(); 
		
		if (heltal == 0)
		{
			System.out.println("noll");
			System.out.println(heltal);
		}
		else if (heltal >= 0)
		{
			System.out.println("positiv");
			System.out.println(heltal);
			}
		else if (heltal <= 0)
		{
			System.out.println("negativ");
			System.out.println(heltal);
		}
		
	}

}
