package lab3;

import java.util.Scanner;

public class P3_5 {
	public static void main(String[] args) {
	    Scanner input = new Scanner(System.in);

	    System.out.print("Mata in tre namn: ");
	    String name1 = input.next();
	    String name2 = input.next();
	    String name3 = input.next();

	    String temp = "";

	    if (name1.compareTo(name2) > 0) {
	        temp = name1;
	        name1 = name2;
	        name2 = temp;
	    }

	    if (name2.compareTo(name3) > 0) {
	        temp = name2;
	        name2 = name3;
	        name3 = temp;
	    }

	    if (name1.compareTo(name2) > 0) {
	        temp = name1;
	        name1 = name2;
	        name2 = temp;
	    }

	    System.out.println(name1);
	    System.out.println(name2);
	    System.out.println(name3);

	    input.close();
	}


}
