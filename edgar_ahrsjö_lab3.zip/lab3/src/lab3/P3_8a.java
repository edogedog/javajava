package lab3;

import java.util.Scanner;

public class P3_8a {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		System.out.print("Var god mata in en textsträng: ");
		String inputString = input.nextLine();
		
		for (int i = 0; i < inputString.length(); i++)
		{
			if (Character.isUpperCase(inputString.charAt(i)))
			{
				System.out.print(inputString.charAt(i));
			}
		}
	}
}