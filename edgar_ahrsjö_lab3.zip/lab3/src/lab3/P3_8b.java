package lab3;

import java.util.Scanner;

public class P3_8b {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		System.out.print("Var god mata in en textsträng: ");
		String inputString = input.nextLine();
		
		for (int i = 0; i < inputString.length(); i += 2)
		{
			System.out.print(inputString.charAt(i));
		}
	}
}