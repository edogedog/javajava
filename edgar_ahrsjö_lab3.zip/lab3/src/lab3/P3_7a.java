package lab3;

import java.util.Scanner;

public class P3_7a {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		System.out.print("Skriv en tal serie: ");
		int tal = input.nextInt();
		int min = tal;
		int max = tal;
		
		while (tal !=0) {
			tal = input.nextInt();
			if (tal != 0 && tal > max)
				
				{max = tal;
				}
			else if (tal != 0 && tal < min)
			{
				min = tal;
				
			}
				}
			
			System.out.println("min och max: " + min + " " + max);
			
			
	}
		
}

