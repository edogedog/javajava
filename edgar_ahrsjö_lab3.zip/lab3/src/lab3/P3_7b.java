package lab3;

import java.util.Scanner;

public class P3_7b {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		System.out.print("Skriv en tal serie: ");
		int tal = input.nextInt();
		int min = tal;
		int max = tal;
		int temp = 0;
		int odd = 0;
		int even = 0;
		
		while (tal !=0) {
				if (tal > max)
					
					{max = tal;
					}
				else if (tal < min)
				{
					min = tal;
					
				}
				temp = tal%2;
				if (temp == 0)
				{even++;}
				else
				{odd ++;}
				tal = input.nextInt();
			
			}
			
			System.out.println("min och max: " + min + " " + max);
			System.out.println("even och odd: " + even + " " + odd);
			
			
	}
		
}

