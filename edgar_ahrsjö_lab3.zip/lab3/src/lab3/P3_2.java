package lab3;

import java.util.Scanner;

public class P3_2 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Mata in ett heltal1: ");
		int heltal1 = input.nextInt(); 
		System.out.print("Mata in ett heltal2: ");
		int heltal2 = input.nextInt(); 
		System.out.print("Mata in ett heltal3: ");
		int heltal3 = input.nextInt(); 
		
		if (heltal1 == heltal2 && heltal2 == heltal3)
		{
			System.out.println("alla lika");
		}
		else if (heltal1 != heltal2 && heltal1 != heltal3 && heltal3 != heltal2)
		{
			System.out.println("alla olika");
			}
		else
		{
			System.out.println("varken eller");
		}
		
	}

}
