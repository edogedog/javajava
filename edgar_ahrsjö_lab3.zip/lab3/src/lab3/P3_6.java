package lab3;

import java.util.Scanner;

public class P3_6 {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		int start = input.nextInt();
		int stop = input.nextInt();
		
		int min = Math.min(start, stop);
		int max = Math.max(start, stop);
		int tot = 0;
		
		for (int i = min + 1; i <= max; i++) {
			tot = tot + i;
		}
		
		System.out.println(tot);
	}
}