package lab3;

import java.util.Scanner;

public class P3_6 {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		
		int start = input.nextInt();
		int stop = input.nextInt();
		int tot = 0;
		
		int min = Math.min(start, stop);
		int max = Math.max(start, stop);
		
		for (int i = min; i <= max; i++)
		{
			if (i == min || i == max)
			{
				if (i % 2 != 0)
				{
					tot += i;
				}
			}
			else
			{
				tot += i;
			}
		}
		
		System.out.println(tot);
	}
}