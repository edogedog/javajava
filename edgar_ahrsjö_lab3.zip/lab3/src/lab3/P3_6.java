package lab3;

import java.util.Scanner;

public class P3_6 {
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		System.out.print("Mata in start och stop: ");
		int start = input.nextInt();
		int stop = input.nextInt();
		int dif = Math.abs(start - stop);
		int tot = 0;
		
		for (int i = start; i <= stop; i++) {
			System.out.println(i);
			tot = tot + i;
			
		}
		System.out.println("svaret är:");
		System.out.println(tot);

		
	}

}
